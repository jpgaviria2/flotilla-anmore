import"./CWj6FrbW.js";import{f as t,d as o,j as p,k as d,r as i,b as n}from"./6Bz4ICcI.js";var c=t('<div class="flex items-center justify-between px-4 py-2 text-sm font-bold uppercase"><!></div>');function v(a,r){var e=c(),s=o(e);p(s,()=>r.children??d),i(e),n(a,e)}export{v as S};
//# sourceMappingURL=C4_Zsdzx.js.map
