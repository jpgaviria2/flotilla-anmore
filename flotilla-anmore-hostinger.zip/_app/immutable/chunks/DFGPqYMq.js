import"./CWj6FrbW.js";import{f as i,j as o,b as d,d as n,k as m,r as l}from"./6Bz4ICcI.js";var p=i('<div class="ml-sai mt-sai mb-sai hidden max-h-screen w-60 flex-shrink-0 flex-col gap-1 bg-base-300 md:flex"><!></div>');function f(s,e){var a=p(),r=n(a);o(r,()=>e.children??m),l(a),d(s,a)}export{f as S};
//# sourceMappingURL=DFGPqYMq.js.map
