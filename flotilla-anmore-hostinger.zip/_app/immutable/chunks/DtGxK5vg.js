import{a5 as a}from"./CrcLliqh.js";class r extends a{async enable(e){}async disable(e){}}export{r as SafeAreaWeb};
//# sourceMappingURL=DtGxK5vg.js.map
