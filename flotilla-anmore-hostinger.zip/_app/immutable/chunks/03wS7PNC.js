import{p as e}from"./SGjxINux.js";import{s as r}from"./aVCWlL1L.js";import"./CJxgCt85.js";import"./CrcLliqh.js";const s=r({key:"theme",defaultValue:window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light",storage:e});export{s as t};
//# sourceMappingURL=03wS7PNC.js.map
