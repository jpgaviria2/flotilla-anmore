import{l as o,a as r}from"../chunks/Ctm1RJVm.js";export{o as load_css,r as start};
//# sourceMappingURL=start.D-8Mcwg8.js.map
