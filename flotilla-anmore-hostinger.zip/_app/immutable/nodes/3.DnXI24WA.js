import"../chunks/CWj6FrbW.js";import{f as s,j as e,b as t,d as i,k as n,r as p}from"../chunks/6Bz4ICcI.js";var d=s('<div class="flex h-full w-full flex-col"><!></div>');function m(a,l){var o=d(),r=i(o);e(r,()=>l.children??n),p(o),t(a,o)}export{m as component};
//# sourceMappingURL=3.DnXI24WA.js.map
