import{r as e}from"../chunks/7n9ZZ9HD.js";const o=()=>{throw e(302,"/feed")},t=Object.freeze(Object.defineProperty({__proto__:null,load:o},Symbol.toStringTag,{value:"Module"}));export{t as universal};
//# sourceMappingURL=18.CBwybeyW.js.map
