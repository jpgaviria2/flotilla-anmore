import"../chunks/CWj6FrbW.js";import"../chunks/Cxg0_B-m.js";import{f as a,b as m,d as s,r as e}from"../chunks/6Bz4ICcI.js";import{A as i}from"../chunks/h3wIeU75.js";var n=a('<div class="content column"><!></div>');function f(r){var o=n(),t=s(o);i(t,{}),e(o),m(r,o)}export{f as component};
//# sourceMappingURL=27.7gc3a92k.js.map
