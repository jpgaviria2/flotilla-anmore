import{l as o,a as r}from"../chunks/BhWvudlQ.js";export{o as load_css,r as start};
//# sourceMappingURL=start.CttXrqwM.js.map
