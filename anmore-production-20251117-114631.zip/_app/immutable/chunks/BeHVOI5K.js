import"./CWj6FrbW.js";import{p as t,f as r,d as p,j as i,r as c,m as d,b as f,c as l,k as m}from"./PcQuwC8S.js";import{s as n}from"./BdPIFpiY.js";var v=r("<div><!></div>");function S(e,s){t(s,!0);var a=v(),o=p(a);i(o,()=>s.children??m),c(a),d(()=>n(a,1,`flex flex-col gap-1 px-2 py-4 ${s.class??""}`)),f(e,a),l()}export{S};
//# sourceMappingURL=BeHVOI5K.js.map
