import{w as a}from"./OekODzlO.js";import{r as i}from"./Wyw8PSZ2.js";import{i as p}from"./DEOuLqfR.js";const t=a(null),r=s=>{const o=i();return t.set({id:o,...s}),setTimeout(()=>e(o),s.timeout||5e3),o},e=s=>t.update(o=>(o==null?void 0:o.id)===s?null:o),d=s=>{p(s),r({message:"Copied to clipboard!"})};export{e as a,d as c,r as p,t};
//# sourceMappingURL=BMjkfxM5.js.map
