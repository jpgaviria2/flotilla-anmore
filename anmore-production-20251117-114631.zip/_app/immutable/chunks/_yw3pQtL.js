import{K as S,L as h,M as k,N as L,S as M}from"./PcQuwC8S.js";function t(r,i){return r===i||(r==null?void 0:r[M])===i}function q(r={},i,a,T){return S(()=>{var f,s;return h(()=>{f=s,s=[],k(()=>{r!==a(...s)&&(i(r,...s),f&&t(a(...f),r)&&i(null,...f))})}),()=>{L(()=>{s&&t(a(...s),r)&&i(null,...s)})}}),r}export{q as b};
//# sourceMappingURL=_yw3pQtL.js.map
