import{a0 as a}from"./DEOuLqfR.js";class r extends a{async enable(e){}async disable(e){}}export{r as SafeAreaWeb};
//# sourceMappingURL=D5_WZS-f.js.map
