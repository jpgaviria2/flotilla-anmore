import{p as e}from"./BDhsddBV.js";import{s as r}from"./CE2-R4xo.js";import"./Wyw8PSZ2.js";import"./DEOuLqfR.js";const s=r({key:"theme",defaultValue:window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light",storage:e});export{s as t};
//# sourceMappingURL=CIlYTw6i.js.map
