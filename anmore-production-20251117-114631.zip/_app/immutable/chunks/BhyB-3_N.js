import"./CWj6FrbW.js";import{f as l,j as t,b as c,s as h,d as e,k as n,r}from"./PcQuwC8S.js";var m=l('<div class="column gap-4 py-12"><h1 class="superheading"><!></h1> <p class="text-center"><!></p></div>');function u(p,i){var a=m(),s=e(a),d=e(s);t(d,()=>i.title??n),r(s);var o=h(s,2),v=e(o);t(v,()=>i.info??n),r(o),r(a),c(p,a)}export{u as P};
//# sourceMappingURL=BhyB-3_N.js.map
