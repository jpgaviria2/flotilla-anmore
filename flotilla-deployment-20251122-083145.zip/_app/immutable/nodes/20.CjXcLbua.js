import"../chunks/CWj6FrbW.js";import"../chunks/CK_wV4o5.js";import{f as a,b as m,d as s,r as e}from"../chunks/PcQuwC8S.js";import{A as i}from"../chunks/B_JwTGBP.js";var n=a('<div class="content column"><!></div>');function f(r){var o=n(),t=s(o);i(t,{}),e(o),m(r,o)}export{f as component};
//# sourceMappingURL=20.CjXcLbua.js.map
