import{a4 as a}from"./5lv1au-5.js";class r extends a{async enable(e){}async disable(e){}}export{r as SafeAreaWeb};
//# sourceMappingURL=lKYeTTnL.js.map
