import{p as e}from"./BzZ5JJqL.js";import{s as r}from"./HqcahQfL.js";import"./CtV_gQDT.js";import"./5lv1au-5.js";const s=r({key:"theme",defaultValue:window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light",storage:e});export{s as t};
//# sourceMappingURL=B0lsUBVo.js.map
