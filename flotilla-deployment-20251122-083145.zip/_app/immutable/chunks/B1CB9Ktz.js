import{w as a}from"./D4DWso6k.js";import{r as p}from"./CtV_gQDT.js";import{f as r}from"./5lv1au-5.js";const t=a(null),e=s=>{const o=p();return t.set({id:o,...s}),setTimeout(()=>i(o),s.timeout||5e3),o},i=s=>t.update(o=>(o==null?void 0:o.id)===s?null:o),d=s=>{r(s),e({message:"Copied to clipboard!"})};export{i as a,d as c,e as p,t};
//# sourceMappingURL=B1CB9Ktz.js.map
